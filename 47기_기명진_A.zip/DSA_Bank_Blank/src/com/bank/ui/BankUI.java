package com.bank.ui;

import java.util.Scanner;

import com.bank.service.BankService;
import com.bank.vo.Account;
import com.bank.vo.Customer;

public class BankUI {

	private BankService manager;
	private Scanner scanner;
	
	/*
	 * 뱅크 서비스에 메서드를 정의하고 호출해서 사
	 */
	public BankUI() {
		manager = new BankService();
		scanner = new Scanner(System.in);
		
		while (true) {
			mainMenu();
			int input = scanner.nextInt();
			
			switch (input) {
				case 1: customerMenu(); break;
				case 2: accountMenu(); break;
				case 3: deposit(); break;
				case 4: withdraw(); break;
				case 5: transfer(); break;
				case 6: 
					System.out.println("프로그램을 종료 합니다.");
					System.exit(0);
				default: System.out.println("잘못 입력 했습니다.");
			}
		}
	}
	
	// 메인메뉴
	public void mainMenu() {
		System.out.println("[ DSA_Bank ]");
		System.out.println("1. 고객관리");
		System.out.println("2. 계좌관리");
		System.out.println("3. 입금하기");
		System.out.println("4. 출금하기");
		System.out.println("5. 이체하기");
		System.out.println("6. 프로그램 종료");
		System.out.print("선택 > ");
	}
	
	// 고객관리
	public void customerMenu() {
		while (true) {
			System.out.println("[ 고객관리 ]");
			System.out.println("1. 고객등록");
			System.out.println("2. 고객검색");
			System.out.println("3. 상위 매뉴로");
			System.out.print("선택 > ");
			
			// 번호를 입력받아 번호에 따른 기능 수행
			int input = scanner.nextInt();
			
			switch (input) {
				case 1: makeCustomer(); break;
				case 2: findCustomer(); break;
				case 3: return;
				default: System.out.println("잘못 입력 했습니다.");
			}
		}
	}
	
	// 계좌관리
	public void accountMenu() {
		while (true) {
			System.out.println("[ 계좌관리 ]");
			System.out.println("1. 계좌생성");
			System.out.println("2. 계좌검색");
			System.out.println("3. 상위 매뉴로");
			System.out.print("선택 > ");
			
			// 번호를 입력받아 번호에 따른 기능 수행
			int input = scanner.nextInt();
			
			switch (input) {
			case 1: makeAccount(); break;
			case 2: findAccount(); break;
			case 3: return;
			default: System.out.println("잘못 입력 했습니다.");
			}			
		}
	}

	// 고객등록
	public void makeCustomer() {
		System.out.println("[ 고객등록 ]");
		System.out.print("이름 : ");
		String name = scanner.next();
		System.out.print("주민번호 : ");
		String ssn = scanner.next();
		
		// 고객 정보 등록
		Boolean isMaked = manager.makeCustomer(name, ssn);
		if (!isMaked) {
			System.out.println("고객정보 등록 실패");
			return;
		}
		System.out.println("고객정보 등록 성공");
	}
	
	// 고객검색
	public void findCustomer() {
		System.out.print("검색할 고객의 주민번호 : ");
		
		// 주민번호를 입력받아 고객 정보 조회
		String ssn = scanner.next();
		Customer customer = manager.findCustomer(ssn);
		if (customer == null) {
			System.out.println("고객정보가 없습니다.");
			return ;
		}
		System.out.println(customer);
	}
	
	// 계좌생성
	public void makeAccount() {
		System.out.print("계좌를 생성할 고객의 주민번호 : ");
		
		// 주민번호를 입력받아 계좌 생성 및 초기 입금액 입력
		String ssn = scanner.next();
		Customer customer = manager.findCustomer(ssn);		
		if (customer == null) {
			System.out.println("고객 정보가 없습니다.");
			return ;
		}
		System.out.print("입금할 금액 : ");
		int depositAmmount = scanner.nextInt();
		Account account = manager.makeAccount(customer, depositAmmount);
		System.out.println(account);
	}
	
	// 계좌검색
	public void findAccount() {
		System.out.print("검색할 계좌번호 : ");
		
		// 계좌번호를 입력받아 계좌 조회
		Account account = getAccount();
		if (account == null) {
			return ;
		}
		System.out.println(account);
	}
	
	// 입금하기
	public void deposit() {
		System.out.print("입금할 계좌번호 : ");
		Account account = getAccount();
		if (account == null) {
			return;
		}
		// 입금할 계좌번호와 금액을 입력받아 입금 전, 후 금액을 출력하고 입금처리
		System.out.print("입금할 금액 : ");
		int depositAmount = scanner.nextInt();
		
		System.out.print("출금 전 계좌정보 : ");
		System.out.println(account);
		Boolean isSuccessed = manager.deposit(account, depositAmount);
		if (!isSuccessed) {
			System.out.println("금액은 0보다 작을 수 없습니다.");
		}
		System.out.print("출금 후 계좌정보 : ");
		System.out.println(account);
	}
	
	// 출금하기
	public void withdraw() {
		// 출금할 계좌번호와 금액을 입력받아 출금 전, 후 금액을 출력하고 출금처리
		System.out.print("출금할 계좌번호 : ");		
		Account account = getAccount();
		if (account == null) {
			return;
		}
		
		System.out.print("출금할 금액 : ");
		int withdrawAmount = scanner.nextInt();
		
		System.out.print("출금 전 계좌정보 : ");
		System.out.println(account);
		
		Boolean isSuccessed = manager.withdraw(account, withdrawAmount);
		if (!isSuccessed) {
			System.out.println("잔고가 부족합니다.");
		}
		
		System.out.print("출금 후 계좌정보 : ");
		System.out.println(account);
	}
	
	// 이체하기
	public void transfer() {		
		// 출금, 이체할 계좌번호 및 금액을 입력받아 이체처리
		// 이체 후 출금계좌의 금액 출력
		System.out.print("출금할 계좌번호 : ");
		Account sender = getAccount();
		if (sender == null) {
			return;
		}
		
		System.out.print("이체할 계좌번호 : ");
		Account receiver = getAccount();
		if (receiver == null) {
			return;
		}
		
		System.out.print("이체할 금액 : ");
		int amount = scanner.nextInt();
		int status = manager.transfer(sender, receiver, amount);
		if (status == BankService.AMOUNT_ERROR) {
			System.out.println("금액은 0보다 작을 수 없습니다.");
		}
		if (status == BankService.BALANCE_ERROR) {
			System.out.println("잔고가 부족합니다.");
		}
		System.out.print("이체 후 출금계좌 정보 : ");
		System.out.println(sender);
	}
	
	// findAccount, deposit, withDraw, transfer에서 모두 사용
	Account getAccount() {
		String accNo = scanner.next();
		Account account = manager.findAccount(accNo);
		if (account == null) {
			System.out.println("계좌 정보가 없습니다.");
		}
		return account;
	}
}
