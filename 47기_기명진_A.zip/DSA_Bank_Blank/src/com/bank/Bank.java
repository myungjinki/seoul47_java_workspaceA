package com.bank;

import com.bank.ui.BankUI;

public class Bank {

	public static void main(String[] args) {
		new BankUI();
	}
}
