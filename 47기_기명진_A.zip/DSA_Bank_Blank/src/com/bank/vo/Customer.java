package com.bank.vo;

import java.util.*;

// 고객정보
public class Customer {
	// 멤버 변수
	private String			name; 			// 이름
	private String			ssn;			// 주민번호
	private List<Account>	accountList;	// 계좌 리스트
	
	// 생성자
	public Customer(String name, String ssn) {
		this.name = name;
		this.ssn = ssn;
		accountList = new ArrayList<>();
	}
	
	// getter & setter
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSsn() {
		return ssn;
	}
	
	public List<Account> getAccountList() {
		return accountList;
	}

	// toString()
	// 출력 형식 : DSA_Bank-[고객명: xxxx, 주민등록번호: xxxxxx], 계좌= xxxxxx
	@Override
	public String toString() {
		return "DSA_Bank-[고객명: " + name + ", 주민등록번호: " + ssn + "], 계좌= " + accountList;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Customer customer) {
			return this.ssn.equals(customer.ssn);
		}
		return false;
	}
}
