package com.bank.vo;

// 계좌정보
public class Account {
	// 멤버 변수
	private static final String BANK_CODE 	= "DSA_Bank";	// 은행명
	private static int 			ACCOUNT_NUM = 1000;			// 계좌고유번호
	private String	accNo;	// 계좌번호
	private int		balance;	// 잔고정보
	
	// 생성자
	public Account() {
		accNo = BANK_CODE + ACCOUNT_NUM++;
	}
	
	// getter, setter
	public String getAccNo() {
		return accNo;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	// 입금하기
	public void deposit(long amount) {
		this.balance += amount;
	}
	
	// 출금하기
	public void withdraw(long amount) {
		this.balance -= amount;		
	}
	
	// 이체하기
	public void transfer(Account toAccount, long amount) {
		this.balance -= amount;
		toAccount.setBalance(toAccount.getBalance() + (int) amount);
	}
	
	// toString
	// 출력 형식: (계좌번호: xxxxxx, 잔고: xxxxxx)
	@Override
	public String toString() {
		return "(계좌번호: " + accNo + ", 잔고: " + balance + ")";
	}
}
