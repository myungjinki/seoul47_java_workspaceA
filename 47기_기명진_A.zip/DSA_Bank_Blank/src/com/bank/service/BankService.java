package com.bank.service;

import java.util.ArrayList;
import java.util.List;

import com.bank.vo.Account;
import com.bank.vo.Customer;

public class BankService {
	public static final int SUCCESS = 0;
	public static final int AMOUNT_ERROR = 1;
	public static final int BALANCE_ERROR = 2;
	// 고객 리스트
	List<Customer> customerList = new ArrayList<>();
	
	// 고객 등록
	public Boolean makeCustomer(String name, String ssn) {
		if (name == null || name == "") {
			return false;
		}
		if (isValidSsn(ssn) == false) {
			return false;			
		}
		Customer customer = new Customer(name, ssn);
		if (customerList.contains(customer)) {
			return false;
		}
		customerList.add(customer);
		return true;
	}
	
	// 고객 검색
	public Customer findCustomer(String ssn) {
		if (isValidSsn(ssn) == false) {
			return null;			
		}
		Customer customer = new Customer("", ssn);
		int customerIndex = customerList.indexOf(customer);
		if (customerIndex == -1) {
			return null;
		}
		return customerList.get(customerIndex);
	}
	
	boolean isValidSsn(String ssn) {
		if (ssn == null || ssn == "") {
			return false;			
		} else if (ssn.length() > 14) {
			return false;
		} else if (ssn.length() < 14) { // 추가: 미만일때도 처리
			return false;
		} else if (ssn.charAt(6) != '-') {
			return false;
		}
		return true;
	}
	
	// 계좌 등록
	public Account makeAccount(Customer customer, int depositAmmount) {
		Account account = new Account();
		account.setBalance(depositAmmount);
		customer.getAccountList().add(account);
		return account;
	}
	
	// 계좌 검색
	public Account findAccount(String accNo) {
		for (Customer customer : customerList) {
			List<Account> accounts = customer.getAccountList();
			for (Account account : accounts) {
				if (account.getAccNo().equals(accNo)) {
					return account;
				}
			}
		}
		return null;
	}
	
	// 입금하기
	public Boolean deposit(Account account, long amount) {
		if (amount < 0) {
			return false;
		}
		account.deposit(amount);
		return true;
	}
	
	// 출금하기
	public Boolean withdraw(Account account, long amount) {
		if (account.getBalance() - amount < 0) {
			return false;
		}
		account.withdraw(amount);
		return true;
	}
	
	// 이체하기
	public int transfer(Account sender, Account receiver, long amount) {
		
		if (amount < 0) {
			return AMOUNT_ERROR;
		}
		if (sender.getBalance() - amount < 0) {
			return BALANCE_ERROR;
		}
		sender.transfer(receiver, amount);
		return SUCCESS;
	}
}
